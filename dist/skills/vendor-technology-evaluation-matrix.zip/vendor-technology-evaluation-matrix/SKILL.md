---
name: vendor-technology-evaluation-matrix
description: Build a weighted vendor or technology evaluation matrix: criteria and weights, 0-5 scoring, must-have pass/fail, comparative analysis, 3-year cost, risk, stakeholder alignment, sensitivity analysis, recommendation and decision record. Use when comparing vendors, tools or platforms or documenting a selection decision.
---

# Vendor and Technology Evaluation Matrix

Adapted from Recipe 44 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Gather: project context, options, must-have and nice-to-have requirements, stakeholder priorities, proposed criteria and weights, evidence per option (proposals, pricing, demo notes), budget limits.
2. Finalise the framework: categories, weights summing to 100%, sub-criteria. Scale: 5 exceeds, 4 fully meets, 3 adequately meets, 2 partially meets, 1 does not meet, 0 missing.
3. Run the must-have check first (pass/fail per option). Flag or eliminate any option that fails a must-have.
4. Score each criterion per option with a note citing the evidence. Show raw scores, weighted scores, category subtotals and total.
5. Add comparative analysis per category (leader, differentiators, ties), 3-year cost table including hidden costs, per-option risk table (likelihood, impact, mitigation), and stakeholder alignment.
6. Run sensitivity analysis: change the heaviest weights, state whether any option dominates regardless, and where the decision flips.
7. Recommend a first choice, a second choice and when it would win, risks to monitor, and a short approval summary (process, options, findings, rationale, approvals needed).

## Constraints

- Base every score on documented evidence. Where evidence is missing, score conservatively and mark [VERIFY: x]. For regulated outsourcing, add third-party and exit-plan criteria.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
