---
name: training-material-development
description: Develop a training programme: learning objectives, course structure, module content with activities, facilitator guide, participant materials and assessment. Use when building compliance, onboarding or process training for a defined audience and format.
---

# Training Material Development

Adapted from Recipe 64 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect: topic, audience and prior knowledge, format and duration, source content, desired outcomes, constraints.
2. Objectives: one terminal objective and 5-8 measurable enabling objectives using Bloom verbs (verb, content, condition).
3. Structure: module table (Module | Topic | Duration | Key outcome), prerequisites, learning path.
4. For each module: duration, objectives, content outline with key points and examples, key concepts, one activity (type, duration, instructions, debrief questions), transition to the next module.
5. Facilitator guide: preparation, materials, minute-by-minute session flow, tips, common challenges and how to handle them, energy management.
6. Participant materials: pre-work, handouts, reference guide, job aid.
7. Assessment: knowledge check tied to each objective, pass mark, and evidence of completion for records.

## Constraints

- Every activity must trace to an objective. For mandatory regulatory training, keep attendance, assessment and refresher-interval evidence, and mark the regulatory basis [VERIFY: x] if unconfirmed.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
