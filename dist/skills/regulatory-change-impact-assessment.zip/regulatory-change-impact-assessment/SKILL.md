---
name: regulatory-change-impact-assessment
description: Assess the impact of a new or changed regulation: applicability, requirement-by-requirement gap analysis, impact by function, risk of non-compliance and delay, phased roadmap, resource estimate, open legal questions and next steps. Use when a regulation, guideline or standard changes and you need to decide what applies and what to do by when.
---

# Regulatory Change Impact Assessment

Adapted from Recipe 46 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect: regulation name, effective date, enforcement date, jurisdiction, the text or a reliable summary, organisation profile (industry, size, footprint, affected population), current compliance state, known gaps.
2. Applicability: list threshold criteria and the organisation's status against each. Conclude fully applies / partially applies / does not apply. Separate what applies, what is exempt, and what needs legal review.
3. Requirements and gaps: table of Requirement | Description | Current state | Gap | Priority (Critical now, High 90 days, Medium by effective date, Low within a year).
4. Impact by function: legal/compliance, IT, operations, sales/marketing, HR, finance, customer service, vendor management. State impact level, changes required and resource estimate.
5. Risk: consequences of non-compliance (penalties, business, reputation) and of delay (grace-period risk, enforcement likelihood, mitigations).
6. Roadmap: 0-30 days, 30-90 days, pre-effective date, post-effective (monitoring, audit preparation). Then a resource table (internal FTE, external cost, timeline) and dependencies.
7. Close with questions for legal review and next actions with owners.

## Constraints

- Check dates, thresholds and article references against the primary source. Mark gaps in the source as [VERIFY: x] and missing figures as [QUANTIFY: x]. Planning aid only: interpretation and decisions stay with legal and compliance. Flag any clock that starts earlier than the effective date, and any second regime that also applies.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
