---
name: dashboard-narrative
description: Turn dashboard data into a written narrative: headline, metric-by-metric story, bright spots, concerns, trends, recommended actions, open questions and talking points. Use when someone needs the "so what" of a dashboard or report for a named audience.
---

# Dashboard Narrative Generation

Adapted from Recipe 51 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect: dashboard and period, the data by category, context and recent events, comparisons (prior period, same period last year, targets), the audience and their key questions.
2. Write a 3-4 sentence executive summary: headline, trend, implication, action.
3. For each metric area give: the numbers, the context against target and history, the driver, and why it matters.
4. List bright spots and areas of concern, each with why it matters and, for concerns, a suggested action.
5. Describe short-term versus medium-term trends and what is changing versus stable.
6. Give up to three recommended actions with reason and expected impact, the questions the data raises, and talking points (lead with, emphasise, expect questions on).

## Constraints

- State what the data shows, not just what it is. Separate fact from inference. Never explain a movement with a cause the data does not support: label it a hypothesis and say what would test it.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
