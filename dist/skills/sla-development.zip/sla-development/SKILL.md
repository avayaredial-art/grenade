---
name: sla-development
description: Develop a Service Level Agreement: scope, service hours, metrics and targets, priority classification, measurement method, roles, escalation, service credits, exclusions, reporting and review. Use when drafting or revising an SLA or operating-level agreement between a provider and a recipient.
---

# Service Level Agreement Development

Adapted from Recipe 50 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect: service overview, provider and recipient, current performance, stakeholder expectations, constraints on what can be committed, service hours, known issues.
2. Draft in this order: header (name, version, dates, parties, owner, approvals); service description (in scope, out of scope, hours, holidays); metrics table (Metric | Definition | Target | Measurement | Reporting) covering availability, response, resolution, quality, volume; priority table P1-P4 with definitions, examples, response and resolution targets.
3. Measurement methodology per metric: calculation, data source, exclusions, frequency. A target without a measurement method is not an SLA term.
4. Roles of provider and recipient; escalation table (level, trigger, contact, expected response) for breaches, complaints and emergencies.
5. Remedies: what triggers a credit, how it is calculated, caps, how applied. Exclusions: maintenance windows, force majeure, recipient-caused delay.
6. Reporting contents, frequency, distribution, and a review cycle with a change process.
7. Check commitments against what the provider can actually deliver today and flag any target above current performance.

## Constraints

- Targets must be measurable and realistic. For ICT or outsourcing arrangements, flag where regulatory contract requirements (for example audit, exit, subcontracting, incident notice) also need clauses. Draft for legal and owner review.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
