---
name: knowledge-base-faq-generation
description: Build a knowledge base from support data: group tickets into user-facing categories, prioritise articles by volume and impact, merge question variants, decide single versus multiple articles, list search terms, then write and review articles. Use when turning tickets, queries or incident themes into FAQs or help articles.
---

# Knowledge Base and FAQ Generation

Adapted from Recipe 94 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect the ticket analysis: top categories with volumes, common causes, resolutions.
2. Group tickets into logical categories as users would look for them, not as the team files them.
3. Prioritise articles by volume and impact. Identify variations of the same question (for example "cannot log in" versus "forgot password") and decide which need one article and which need several.
4. For each topic list the search terms users actually use.
5. Propose the knowledge base structure (categories, navigation, article template).
6. Write each article: question-style title, short answer first, numbered steps, expected result, troubleshooting, related articles.
7. Review: remove duplicates, check every step against a real resolution, and set an owner and review date per article.

## Constraints

- Never publish a fix that no ticket resolution supports. Strip personal data and internal system names from examples. Keep answers short enough to use on first read.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
