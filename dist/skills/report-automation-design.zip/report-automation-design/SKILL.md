---
name: report-automation-design
description: Design the automation of a recurring report: requirements, data architecture and quality rules, tool stack with alternatives, output and distribution spec, phased roadmap, metric definitions and risks. Use when a weekly, monthly or board report is built by hand and should be automated.
---

# Report Automation Design

Adapted from Recipe 58 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect: report name, frequency, hours spent, audience, the manual process step by step with time per step, report sections, data sources, pain points, desired improvements, available tools and constraints.
2. Summarise: current state, recommended approach, expected time saving, complexity, dependencies.
3. Requirements: functional (Requirement | Priority | Current | Automated) and non-functional (performance, reliability, flexibility, maintainability).
4. Data architecture: source systems and access method, flow (source, staging, transformation, output), each transformation with logic, and data quality rules.
5. Automation stack: component, tool and reason; plus alternatives with pros, cons and when to choose.
6. Output spec: sections with data source and refresh rate, template design, distribution channels, audience, format, timing.
7. Roadmap in three phases (foundation, automation, enhancement) with durations, milestones and resources; metric definitions with exact formulas and source fields.
8. Add controls: reconciliation to source, access rights, change log, owner, fallback to the manual process, and how errors are caught before distribution.

## Constraints

- Do not design around data you cannot access. Where a report feeds a regulator or the board, keep a human review step and an evidence trail. Mark unknown effort as [QUANTIFY: x].
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
