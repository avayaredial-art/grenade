---
name: legal-research-summarization
description: Organise legal research: break a legal question into issues, identify jurisdictions and authorities, organise findings by jurisdiction, analyse implications, develop recommendations and draft a summary memorandum. Use when framing or summarising legal or regulatory research for a decision.
---

# Legal Research Summarization

Adapted from Recipe 99 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Frame the question: research question, business context and what decision depends on it, jurisdictions, deadline. Break it into specific legal issues, list threshold questions to resolve first, and note which facts matter most.
2. Identify applicable laws, regulators and the kinds of authority to look for (statutes, regulations, case law, supervisory guidance).
3. Organise findings: summary by jurisdiction, key authorities with citations, current requirements, recent or pending changes, areas of uncertainty or conflicting authority, and a comparison table where several jurisdictions apply.
4. Analyse implications for the business context, then develop options and a recommendation with the strongest opposing view tested before it is set aside.
5. Draft the summary memorandum: question, short answer, background facts, analysis, recommendation, open points.
6. Review: every citation checked against the primary source; assumptions, inferences and facts kept apart.

## Constraints

- Never invent authorities, citations or case names. Mark anything not verified in a primary source [VERIFY: x] and secondary-only sources [S]. This is a research organiser, not legal advice: conclusions go to qualified counsel before reliance.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
