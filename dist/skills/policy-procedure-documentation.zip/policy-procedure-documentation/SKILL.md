---
name: policy-procedure-documentation
description: Draft a complete policy or procedure document: purpose, scope, definitions, policy statement, roles, procedures, exceptions, non-compliance, related policies, revision history, plus a compliance mapping, rollout guide and FAQ. Use when asked to write, draft or rework a policy, SOP-level procedure or standard, or to encode regulatory requirements into an internal policy.
---

# Policy and Procedure Documentation

Adapted from Recipe 41 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect the inputs: policy topic, objectives, applicable regulatory requirements and how each applies, current state, decisions the policy must encode, and stakeholder needs. Ask for what is missing. Mark any unconfirmed regulatory reference [VERIFY: x].
2. Draft the document in this order: header (title, number placeholder, effective date placeholder, version, approval authority, next review date); 1 Purpose; 2 Scope and exclusions; 3 Definitions; 4 Policy statement (required, permitted, prohibited, grouped by topic); 5 Roles and responsibilities with escalation paths; 6 Procedures with timelines; 7 Exceptions (who approves, documentation, time limit); 8 Non-compliance and reporting; 9 Related policies; 10 Revision history; appendices as needed.
3. Add a compliance mapping table: Requirement | Policy section | How addressed. Every stated requirement must map to a section. List any requirement with no home as a gap.
4. Add an implementation guide (rollout, communication outline, training needs, timeline) and a draft FAQ of questions affected staff will ask.
5. Review pass: each obligation is a testable "must/must not" with an owner; no undefined term; exceptions are bounded.

## Constraints

- Specific enough to enforce, flexible enough for reasonable cases. Do not invent regulatory citations. Output is a draft for owner and legal/compliance approval.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
