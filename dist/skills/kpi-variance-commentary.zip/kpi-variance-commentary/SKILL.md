---
name: kpi-variance-commentary
description: Analyse KPI variances and write management commentary: materiality screen, root-cause explanation per material variance, patterns, prioritised actions, watchlist and forecast impact. Use for monthly or quarterly performance reviews, risk and compliance KPI packs, and board reporting.
---

# KPI Variance Analysis and Commentary

Adapted from Recipe 53 of "Top 100 Claude Code Recipes for Knowledge Workers" (personal and commercial use permitted by its licence; not for resale).

## Steps

1. Collect: period, KPI table (actual, target, prior), materiality thresholds (financial and operational), known context, prior-period trends.
2. Executive summary: overall headline, KPIs on track versus off track, largest positive and negative variance, the common theme.
3. Materiality table: KPI | Variance | Material? | Priority. Spend the rest of the analysis on material variances only.
4. For each material variance: performance (actual vs target, amount, %), trend, what happened, why (primary driver quantified where possible, contributing factors, one-time or recurring), why it matters, recommended action with expected impact, outlook.
5. Pattern analysis: shared root causes, leading/lagging links, systemic versus isolated.
6. Action summary ranked by priority with the KPIs each addresses; watchlist of non-material variances; implications for quarter-end and full-year outlook and any target change to consider.

## Constraints

- Explain and diagnose, do not just describe. Recompute every variance from the supplied figures before writing. Mark unexplained variances as unexplained and list the data needed to explain them.
- Ask for missing inputs once, together, before drafting.
- Output is a draft until the owner approves it.
